package com.kiranacademy.myacademy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyacademyApplicationTests {

	@Test
	void contextLoads() {
	}

}
