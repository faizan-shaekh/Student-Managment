package com.kiranacademy.myacademy.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.kiranacademy.myacademy.entity.Student;
import com.kiranacademy.myacademy.service.StudentService;

@RestController
public class studentController {
    
    @Autowired
    StudentService service;
   
   

    //1
	@GetMapping("/getbyrollnum/{rollnum}")
	public Student getbyrollnum(@PathVariable int rollnum) {
		Student list = service.getdatabyrollnum(rollnum);
		return list; 
	}
	//2
    @GetMapping("/getall")
	public List<Student> getall(){
		List<Student> list = service.getall();
		return list;
	}
    //3
	@PostMapping("/postsingle")
    public String addsingledata(@RequestBody Student s) {
      String msg = service.addsingledata(s);
    	
    	return msg;
    }
	//4
	@PostMapping("/postmultiple")
	public String postmultiple(@RequestBody List<Student> al) {
		
		String msg = service.postmultiple(al);
		return msg;
	}
	//5
	@DeleteMapping("/deletebyid/{id}")
	public String deletebyid(@PathVariable int id) {
		String msg = service.deleteone(id);
		return msg;
	}
	//6
	@PutMapping("/update")
	public String update(@RequestBody Student s) {
		String msg = service.update(s);
		return msg;
	}
	//7
	@PostMapping("/saveupdate")
	public String saveupdate(@RequestBody Student s) {
		String msg = service.update(s);
		return msg;
	}
	//8
	@PostMapping("/persist")
	public String persist(@RequestBody Student s) {
		String msg = service.persist(s);
		return msg;
	}
	//9
	@PostMapping("/merge/{id}/{marks}")
	public String merge(@PathVariable int id,@PathVariable double marks) {
		System.out.println("controller : "+id+marks);
		String msg = service.merge(id,marks);
		return msg;
	}
	//10
	@GetMapping("/lessthan70")
	public List<Student> markslessthan70() {
		
		List<Student> list = service.markslessthan70();
		
		return list;
	}
	//11
	@GetMapping("/greaterthan70")
	public List<Student> greaterthan70() {
		
		List<Student> al = service.greaterthan70();
		
		return al;
	}
	//12
	@GetMapping("/marksgt/{marks}")
	public List<Student> greaterthan(@PathVariable double marks) {
		
		List<Student> al = service.greaterthan(marks);
		
		return al;
	}
	//13
	@GetMapping("/markslt/{marks}")
	public List<Student> lessthan(@PathVariable double marks) {
		
		List<Student> al = service.lessthan(marks);
		
		return al;
	}
	//14
	@GetMapping("/markslessequal/{marks}")
	public List<Student> lessequal(@PathVariable double marks) {
		
		List<Student> al = service.lessequal(marks);
		
		return al;
	}
	//15
	@GetMapping("/marksgreaterqual/{marks}")
	public List<Student> greaterqual(@PathVariable double marks) {
		
		List<Student> al = service.greaterequal(marks);
		
		return al;
}
	//16
	@GetMapping("/rollgtandmarkgt/{rollnum}/{marks}")
	public List<Student> rollnumandmarksgt(@PathVariable int rollnum,@PathVariable double marks){
		System.out.println(rollnum+marks);
		List<Student> list = service.rollnumandmarksgt(rollnum, marks);
		
		return list;
	}
	//17
	@GetMapping("/rollltandmarklt/{rollnum}/{marks}")
	public List<Student> rollnumandmarkslt(@PathVariable int rollnum,@PathVariable double marks){
		System.out.println(rollnum+marks);
		List<Student> list = service.rollnumandmarkslt(rollnum, marks);
		
		return list;
	}
	//18
	@GetMapping("/rollgeandmarkge/{rollnum}/{marks}")
	public List<Student> rollnumandmarksge(@PathVariable int rollnum,@PathVariable double marks){
		System.out.println(rollnum+marks);
		List<Student> list = service.rollnumandmarksge(rollnum, marks);
		
		return list;
	}
	//19
	@GetMapping("/rollleandmarkle/{rollnum}/{marks}")
	public List<Student> rollnumandmarksle(@PathVariable int rollnum,@PathVariable double marks){
		System.out.println(rollnum+marks);
		List<Student> list = service.rollnumandmarksle(rollnum, marks);
		
		return list;
	}
	//20
	@GetMapping("/marksbetween/{low}/{high}")
	public List<Student> marksbetween(@PathVariable double low,@PathVariable double high) {
		List<Student> list = service.marksbetween(low, high);
		return list;
	}
    //21
	@GetMapping("/marksequal/{marks}")
	public List<Student> marksequal(@PathVariable double marks) {
		List<Student> list = service.marksequal(marks);
		return list;
	}
	//22
	@GetMapping("/rollnumequal/{rollnum}")
	public List<Student> rollnumequal(@PathVariable int rollnum) {
		List<Student> list = service.rollnumequal(rollnum);
		return list;
	}
    //23
	@GetMapping("/nameequal/{name}")
	public List<Student> nameequal(@PathVariable String name) {
		List<Student> list = service.nameequal(name);
		return list;
	}
	//24
	@GetMapping("/namenotequal/{name}")
	public List<Student> namenotequal(@PathVariable String name) {
		List<Student> list = service.namenotequal(name);
		return list;
	}
	//25
	@GetMapping("/rollnumnotequal/{rollnum}")
	public List<Student> rollnumnotequal(@PathVariable int rollnum) {
		List<Student> list = service.rollnumnotequal(rollnum);
		return list;
	}
	//26
	@GetMapping("/marksnotequal/{marks}")
	public List<Student> marksnotequal(@PathVariable double marks) {
		List<Student> list = service.marksnotequal(marks);
		return list;
	}
	//27
	@GetMapping("/containname")
	public List<Student> containname(@RequestBody List<String> name) {
		System.out.println(name);
		List<Student> list = service.containname(name);
		return list;
	}
	//28
	@GetMapping("/namestart/{name}")
	public List<Student> namelike(String name){
		return service.namelike(name);
	}
	//29
	@GetMapping("/load/{id}")
	public Student load(@PathVariable int id) {
		System.out.println(id);
		Student s = service.load(id);
		return s;
	}
	//30
	@GetMapping("/topper")
	public Set<Student> gettoper() {
		Set<Student> set = service.gettop();
		System.out.println("controller : "+set);
		return set;
	}
	@DeleteMapping ("/deleteall")
	public String deletemultiple(@RequestBody List<Integer> id) {
		String msg = service.deletemultiple(id);
		return msg;
	}
}
