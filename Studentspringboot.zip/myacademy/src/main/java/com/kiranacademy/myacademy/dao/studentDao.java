package com.kiranacademy.myacademy.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import javax.swing.event.TreeExpansionEvent;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.kiranacademy.myacademy.entity.Student;

@Repository
public class studentDao {
	@Autowired
	SessionFactory sf;
	
	
	public Student getdatabyrollnum( int rollnum) {
		
		Session session = sf.openSession();
		Student list = session.get(Student.class, rollnum);
		
		
		return list;
	}
	
	public List<Student> getall() {
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(Student.class);
		List<Student> list = cr.list();
		return list;
	}

	public String addsingledata(Student s) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
        Student st = new Student();
		st.setId(s.getId());
		st.setName(s.getName());
		st.setMarks(s.getMarks());
		
		session.save(st);
		tr.commit();
		return "Data added Successful...";
		
	}

	public String postmultiple(List<Student> al) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		for (Student st : al) {
			Student s = new Student();
			s.setId(st.getId());
			s.setName(st.getName());
			s.setMarks(st.getMarks());
			session.save(s);
			
		
		}
		tr.commit();
		
		return "Data saved Successful...";
	}

	public String deletebyid(int id) {
		System.out.println("dao data1 :"+id);
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		Student s =  session.get(Student.class, id);
		session.delete(s);
		
		
		
		tr.commit();
		return "Data delete Successful...";
	}

	public String update(Student s) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		Student ss = new Student();
		ss.setId(s.getId());
		ss.setMarks(s.getMarks());
		ss.setName(s.getName());
		session.update(ss);
		tr.commit();
		return "Data update successful...";
	}

	public String saveupdate(Student s) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		Student ss = new Student();
		ss.setId(s.getId());
		ss.setMarks(s.getMarks());
		ss.setName(s.getName());
		session.saveOrUpdate(ss);
	    tr.commit();
		
		return "Data save or Updated";
	}

	public String persist(Student s) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		Student ss = new Student();
		ss.setId(s.getId());
		ss.setMarks(s.getMarks());
		ss.setName(s.getName());
		session.persist(ss);
		
		tr.commit();
		return "Data saved successful...";
	}

	public String merge(int id,double marks) {
		
		Session session = sf.openSession();
		Student ss = new Student();
		session.get(Student.class, id);
		ss.setMarks(marks);
		Transaction tr = session.beginTransaction();
		Student ss1 = new Student();
		session.get(Student.class, id);
		session.merge(ss);
	
		tr.commit();
		return "data merge successful...";
	}

	public List<Student> markslessthan70() {
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(Student.class);
		cr.add(Restrictions.lt("marks", 70.0));
		List<Student> list = cr.list();
		return list;
	}

	public List<Student> greaterthan70() {
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(Student.class);
		cr.add(Restrictions.gt("marks", 70.0));
		List<Student> list = cr.list();
		return list;
	}

	public List<Student> greaterthan(double marks) {
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(Student.class);
		cr.add(Restrictions.gt("marks", marks));
		List<Student> list = cr.list();
		return list;
	}

	public List<Student> lessthan(double marks) {
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(Student.class);
		cr.add(Restrictions.lt("marks", marks));
		List<Student> list = cr.list();
		return list;
	}
	
	public List<Student> lessequal(double marks) {
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(Student.class);
		cr.add(Restrictions.le("marks", marks));
		List<Student> list = cr.list();
		return list;
	}
	
	public List<Student> greaterequal(double marks) {
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(Student.class);
		cr.add(Restrictions.ge("marks", marks));
		List<Student> list = cr.list();
		return list;
	}
	
	public List<Student> rollnumandmarksgt(int rollnum, double marks) {
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(Student.class);
		cr.add(Restrictions.and(Restrictions.gt("id", rollnum),Restrictions.gt("marks", marks)));
		List<Student> list = cr.list();
		return list;
	}
	
	public List<Student> rollnumandmarkslt(int rollnum, double marks) {
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(Student.class);
		cr.add(Restrictions.and(Restrictions.lt("id", rollnum),Restrictions.lt("marks", marks)));
		List<Student> list = cr.list();
		return list;
	}
	
	public List<Student> rollnumandmarksge(int rollnum, double marks) {
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(Student.class);
		cr.add(Restrictions.and(Restrictions.ge("id", rollnum),Restrictions.ge("marks", marks)));
		List<Student> list = cr.list();
		return list;
	}
	
	public List<Student> rollnumandmarksle(int rollnum, double marks) {
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(Student.class);
		cr.add(Restrictions.and(Restrictions.le("id", rollnum),Restrictions.le("marks", marks)));
		List<Student> list = cr.list();
		return list;
	}
	
	public List<Student> marksbetween(double low, double high) {
		Session sessio = sf.openSession();
		Criteria cr = sessio.createCriteria(Student.class);
		cr.add(Restrictions.between("marks", low, high));
		List<Student> list = cr.list();
		return list;
	}
	
	public List<Student> marksequal(double marks) {
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(Student.class);
		cr.add(Restrictions.eq("marks", marks));
	    List<Student> list = cr.list();
	    return list;
	}

	public List<Student> rollnumequal(int rollnum) {
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(Student.class);
		cr.add(Restrictions.eq("id", rollnum));
	    List<Student> list = cr.list();
	    return list;
	}
	
	public List<Student> nameequal(String name) {
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(Student.class);
		cr.add(Restrictions.eq("name", name));
	    List<Student> list = cr.list();
	    return list;
	}
	
	public List<Student> namenotequal(String name) {
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(Student.class);
		cr.add(Restrictions.ne("name", name));
		List<Student> list = cr.list();
		return list;
	}
	
	public List<Student> rollnumnotequal(int rollnum) {
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(Student.class);
		cr.add(Restrictions.ne("id", rollnum));
		List<Student> list = cr.list();
		return list;
	}
	
	public List<Student> marksnotequal(double marks) {
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(Student.class);
		cr.add(Restrictions.ne("marks", marks));
		List<Student> list = cr.list();
		return list;
	}
	
	public List<Student> containname(List<String> name) {
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(Student.class);
	    cr.add(Restrictions.in("name", name));
		List<Student> list = cr.list();
		return list;
	}
	
	public List<Student> namelike(String name) {
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(Student.class);
		cr.add(Restrictions.like("name", name));
		return cr.list();
	}
	
	public Student load(int id) {
		Session session = sf.openSession();
	
		Student s = session.load(Student.class, id);
		return s;
	}
	
	public Set<Student> gettop() {
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(Student.class);
		List<Student> list = cr.list();
		Set<Student> set = new TreeSet<>();
		set = list.stream().collect(Collectors.toSet());
		return set;
	}
	
	public String deletemultiple(List<Integer> id) {
		
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		for (Integer in : id) {
			 Student s = session.get(Student.class, in);
			 session.delete(s);
		}
		tr.commit();
	   return "All Student deleted successfull...";
	}
}
