package com.kiranacademy.myacademy.service;

import java.util.TreeSet;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kiranacademy.myacademy.dao.studentDao;
import com.kiranacademy.myacademy.entity.Student;

@Service
public class StudentService {
	@Autowired
	studentDao dao;
	public Student getdatabyrollnum(int rollnum) {
		
		Student list = dao.getdatabyrollnum(rollnum);
		return list;
	}
	public List<Student> getall() {
		List<Student> list = dao.getall();
		return list;
	}
	public String addsingledata(Student s) {
		String msg = dao.addsingledata(s);
		return msg;
	}
	public String postmultiple(List<Student> al) {
		String msg = dao.postmultiple(al);
		return msg;
	}
	public String deleteone(int id) {
		String msg = dao.deletebyid(id);
		return msg;
	}
	
	public String update(Student s) {
		String msg = dao.update(s);
		return msg;
	
	}
	public String saveupdate(Student s) {
		String msg = dao.saveupdate(s);
		return msg;
	}
	public String persist(Student s) {
		String msg = dao.persist(s);
		return msg;
	}
	public String merge(int id, double marks) {
		String msg = dao.merge(id,marks);
		return msg;
	}
	public List<Student> markslessthan70() {
		List<Student> list = dao.markslessthan70();
		return list;
	}
	public List<Student> greaterthan70() {
		List<Student> al = dao.greaterthan70();
		return al;
	}
	public List<Student> greaterthan(double marks) {
		List<Student> al = dao.greaterthan(marks);
		return al;
	}
	public List<Student> lessthan(double marks) {
		List<Student> al = dao.lessthan(marks);
		return al;
	}
	public List<Student> lessequal(double marks) {
		List<Student> al = dao.lessequal(marks);
		return al;
	}
	
	public List<Student> greaterequal(double marks) {
		List<Student> al = dao.greaterequal(marks);
		return al;
	}
	
	public List<Student> rollnumandmarksgt(int rollnum, double marks){
		List<Student> list = dao.rollnumandmarksgt(rollnum, marks);
		
		return list;
	}
	
	public List<Student> rollnumandmarkslt(int rollnum, double marks){
		List<Student> list = dao.rollnumandmarkslt(rollnum, marks);
		
		return list;
	}
	public List<Student> rollnumandmarksge(int rollnum, double marks){
		List<Student> list = dao.rollnumandmarksge(rollnum, marks);
		
		return list;
	}
	public List<Student> rollnumandmarksle(int rollnum, double marks){
		List<Student> list = dao.rollnumandmarksle(rollnum, marks);
		
		return list;
	}
	
	public List<Student> marksbetween(double low, double high) {
		List<Student> list = dao.marksbetween(low, high);
		return list;
	}
	
	public List<Student> marksequal(double marks) {
		List<Student> list = dao.marksequal(marks);
		return list;
	}
	public List<Student> rollnumequal(int rollnum) {
		List<Student> list = dao.rollnumequal(rollnum);
		return list;
	}
	
	public List<Student> nameequal(String name) {
		List<Student> list = dao.nameequal(name);
		return list;
	}
	
	public List<Student> namenotequal(String name) {
		List<Student> list = dao.namenotequal(name);
		return list;
	}
	
	public List<Student> rollnumnotequal(int rollnum) {
		List<Student> list = dao.rollnumnotequal(rollnum);
		return list;
	}
	
	public List<Student> marksnotequal(double marks) {
		List<Student> list = dao.marksnotequal(marks);
		return list;
	}
	
	public List<Student> containname(List<String> name) {
		List<Student> list = dao.containname(name);
		return list;
	}
	
	public List<Student> namelike(String name){
		return dao.namelike(name);
	}
	
	public Student load(int id) {
		Student s =dao.load(id);
		return s;
	}
	
	public Set<Student> gettop() {
		Set<Student> set = dao.gettop();
		return set;
	}
	
	public String deletemultiple(List<Integer> l) {
		String msg = dao.deletemultiple(l);
		return msg;
	}
	
}
